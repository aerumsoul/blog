// blog schema file
const mongoose = require("mongoose");

const blogSchema = new mongoose.Schema(
  {
    // blog title
    title: {
      type: String,
      required: true
    },
    // blog content
    body: {
      type: String,
      required: true
    },
    // blog author
    author: {
      type: String,
      default: "anonymous"
    }
  },
  // adds created and updated time
  { timestamps: true }
);

module.exports = mongoose.model("Blog", blogSchema);