// api routes file
const express = require("express");
const Blog = require("../models/Blog");
const router = express.Router();

// create blog
router.post("/blogs", async (req, res) => {
  try {
    const { title, body, author } = req.body;

    // check required fields
    if (!title || !body) {
      return res.status(400).json({ message: "title and body required" });
    }

    const blog = await Blog.create({ title, body, author });
    res.status(201).json(blog);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// get all blogs
router.get("/blogs", async (req, res) => {
  try {
    const blogs = await Blog.find();
    res.json(blogs);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// get one blog
router.get("/blogs/:id", async (req, res) => {
  try {
    const blog = await Blog.findById(req.params.id);
    if (!blog) return res.status(404).json({ message: "blog not found" });
    res.json(blog);
  } catch {
    res.status(400).json({ message: "invalid id" });
  }
});

// update blog
router.put("/blogs/:id", async (req, res) => {
  try {
    const blog = await Blog.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );
    if (!blog) return res.status(404).json({ message: "blog not found" });
    res.json(blog);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// delete blog
router.delete("/blogs/:id", async (req, res) => {
  try {
    const blog = await Blog.findByIdAndDelete(req.params.id);
    if (!blog) return res.status(404).json({ message: "blog not found" });
    res.json({ message: "blog deleted" });
  } catch {
    res.status(400).json({ message: "invalid id" });
  }
});

module.exports = router;